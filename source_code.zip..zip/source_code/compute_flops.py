
import torch
from pathlib import Path
from mmcv import Config
from mmdet.models import build_detector
from mmcv.runner import load_checkpoint
from mmcv.cnn import get_model_complexity_info

weight_path = Path("/kaggle/input/datasets/varshansvarshans/qfdet-vtuav-weights/epoch_11_qfdet_vtuav.pth")
cfg_path = "/kaggle/working/outputs/configs/improved_fusion_test.py"

cfg = Config.fromfile(cfg_path)
model = build_detector(cfg.model, test_cfg=cfg.get("test_cfg"))
load_checkpoint(model, str(weight_path), map_location="cpu")
model.eval()
model = model.cuda()
model.forward = model.forward_dummy

def input_constructor(input_shape):
    v_img = torch.randn(1, *input_shape).cuda()
    t_img = torch.randn(1, *input_shape).cuda()
    return {"img": (v_img, t_img)}

flops, params = get_model_complexity_info(
    model, (3, 512, 512), as_strings=True,
    print_per_layer_stat=False,
    input_constructor=input_constructor
)
print("===== FLOPs =====")
print(f"FLOPs: {flops}")
print(f"Params: {params}")
