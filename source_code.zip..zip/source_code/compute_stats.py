
import time
import torch
from pathlib import Path
from mmcv import Config
from mmcv.parallel import MMDataParallel
from mmdet.models import build_detector
from mmdet.datasets import build_dataset, build_dataloader
from mmcv.runner import load_checkpoint

weight_path = Path("/kaggle/input/datasets/varshansvarshans/qfdet-vtuav-weights/epoch_11_qfdet_vtuav.pth")
cfg_path = "/kaggle/working/outputs/configs/improved_fusion_test.py"

size_mb = weight_path.stat().st_size / (1024 * 1024)

cfg = Config.fromfile(cfg_path)
model = build_detector(cfg.model, test_cfg=cfg.get("test_cfg"))
load_checkpoint(model, str(weight_path), map_location="cpu")
model = MMDataParallel(model, device_ids=[0])
model.eval()

num_params = sum(p.numel() for p in model.parameters())
num_params_m = num_params / 1e6

dataset = build_dataset(cfg.data.test)
loader = build_dataloader(dataset, samples_per_gpu=1, workers_per_gpu=2, dist=False, shuffle=False)

times = []
with torch.no_grad():
    for i, data in enumerate(loader):
        if i >= 50:
            break
        torch.cuda.synchronize()
        start = time.time()
        model(return_loss=False, rescale=True, **data)
        torch.cuda.synchronize()
        times.append(time.time() - start)

avg_time = sum(times) / len(times)
fps = 1.0 / avg_time

print("===== COMPUTATIONAL METRICS =====")
print(f"Model size: {size_mb:.2f} MB")
print(f"Number of parameters: {num_params_m:.2f} M")
print(f"Average inference time: {avg_time*1000:.2f} ms/image")
print(f"FPS: {fps:.2f}")
