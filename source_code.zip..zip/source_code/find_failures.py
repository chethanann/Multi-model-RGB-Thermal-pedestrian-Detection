
import json
from pathlib import Path

gt_path = Path("/kaggle/working/vtuav_qfdet/annotations/test.json")
pred_path = Path("/kaggle/working/outputs/predictions/stage3_improved_fusion_test.bbox.json")

gt = json.loads(gt_path.read_text())
preds = json.loads(pred_path.read_text())

gt_counts = {}
for ann in gt["annotations"]:
    gt_counts[ann["image_id"]] = gt_counts.get(ann["image_id"], 0) + 1

pred_counts = {}
for p in preds:
    if p["score"] > 0.3:
        pred_counts[p["image_id"]] = pred_counts.get(p["image_id"], 0) + 1

id_to_name = {img["id"]: img["file_name"] for img in gt["images"]}

# Find images where the model missed the most pedestrians (gt count much higher than pred count)
gaps = []
for img_id, gt_n in gt_counts.items():
    pred_n = pred_counts.get(img_id, 0)
    gaps.append((gt_n - pred_n, img_id, gt_n, pred_n, id_to_name.get(img_id, "?")))

gaps.sort(reverse=True)
print("Top 5 worst missed-detection images (gt_count - pred_count):")
for gap, img_id, gt_n, pred_n, fname in gaps[:5]:
    print(f"image_id={img_id} file={fname} ground_truth={gt_n} predicted={pred_n} missed={gap}")
