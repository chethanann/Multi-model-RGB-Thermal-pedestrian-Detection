
import copy
import json
from pathlib import Path

import torch
from mmcv import Config

repo_dir = Path("/kaggle/working/mmdet-rgbtdroneperson")
base_cfg_path = repo_dir / "qfdet_configs" / "qfdet_r50_fpn_1x_vtuav.py"
weight_path = Path("/kaggle/input/datasets/varshansvarshans/qfdet-vtuav-weights/epoch_11_qfdet_vtuav.pth")
out_dir = Path("/kaggle/working/outputs/configs")
data_root = Path("/kaggle/working/vtuav_qfdet")
out_dir.mkdir(parents=True, exist_ok=True)

def detect_num_classes(weight_path):
    ckpt = torch.load(str(weight_path), map_location="cpu")
    state = ckpt.get("state_dict", ckpt)
    candidates = []
    for k, v in state.items():
        if hasattr(v, "shape") and v.ndim == 4 and ("atss_cls.weight" in k or "conv_cls.weight" in k or "cls_logits.weight" in k):
            candidates.append((k, int(v.shape[0])))
    if candidates:
        print("Detected class-head candidates:", candidates[:5])
        return candidates[0][1]
    print("Could not detect class count from checkpoint; using 1.")
    return 1

num_classes = detect_num_classes(weight_path)

def set_num_classes(model_cfg, n):
    for key in ["bbox_head", "bbox_prehead"]:
        if key in model_cfg:
            model_cfg[key]["num_classes"] = n

def configure(split, mode, improved=False):
    cfg = Config.fromfile(str(base_cfg_path))
    set_num_classes(cfg.model, num_classes)
    cfg.data.samples_per_gpu = 1
    cfg.data.workers_per_gpu = 2
    cfg.data.train.ann_file = str(data_root / "annotations" / "train.json")
    cfg.data.train.img_prefix = str(data_root / "fusion" / "train") + "/"
    cfg.data.val.ann_file = str(data_root / "annotations" / "val.json")
    cfg.data.val.img_prefix = str(data_root / "fusion" / "val") + "/"
    cfg.data.test.ann_file = str(data_root / "annotations" / f"{split}.json")
    cfg.data.test.img_prefix = str(data_root / mode / split) + "/"
    cfg.evaluation = dict(interval=1, metric="bbox")
    cfg.work_dir = str(Path("/kaggle/working/outputs/work_dirs") / ("improved" if improved else "baseline") / mode / split)
    if improved:
        cfg.model.test_cfg.nms = dict(type="soft_nms", iou_threshold=0.5, min_score=0.001)
    else:
        cfg.model.test_cfg.nms = dict(type="nms", iou_threshold=0.5)
    name = f"{'improved' if improved else 'baseline'}_{mode}_{split}.py"
    path = out_dir / name
    cfg.dump(str(path))
    return str(path)

paths = {}
for split in ["val", "test"]:
    for mode in ["rgb_only", "thermal_only", "fusion"]:
        paths[f"baseline_{mode}_{split}"] = configure(split, mode, improved=False)
    paths[f"improved_fusion_{split}"] = configure(split, "fusion", improved=True)

with open(out_dir / "config_manifest.json", "w") as f:
    json.dump({"num_classes": num_classes, "configs": paths}, f, indent=2)

print(json.dumps({"num_classes": num_classes, "configs": paths}, indent=2))
