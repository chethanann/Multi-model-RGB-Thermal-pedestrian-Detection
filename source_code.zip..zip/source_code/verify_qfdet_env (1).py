
import torch
import mmcv
import mmdet
from mmdet.datasets import VTUAVdet
from mmdet.models.detectors import QFDet
print("torch:", torch.__version__, "cuda:", torch.cuda.is_available())
print("mmcv :", mmcv.__version__)
print("mmdet:", mmdet.__version__)
print("QFDet and VTUAVdet import OK")
