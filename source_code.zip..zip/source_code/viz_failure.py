
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

gt_path = Path("/kaggle/working/vtuav_qfdet/annotations/test.json")
pred_path = Path("/kaggle/working/outputs/predictions/stage3_improved_fusion_test.bbox.json")
rgb_dir = Path("/kaggle/working/vtuav_qfdet/fusion/test/visible")

gt = json.loads(gt_path.read_text())
preds = json.loads(pred_path.read_text())

target_id = 1076
fname = [img["file_name"] for img in gt["images"] if img["id"] == target_id][0]

gt_boxes = [a["bbox"] for a in gt["annotations"] if a["image_id"] == target_id]
pred_boxes = [(p["bbox"], p["score"]) for p in preds if p["image_id"] == target_id and p["score"] > 0.3]

img_path = rgb_dir / fname
print("Looking for image at:", img_path)
img = Image.open(img_path)
fig, ax = plt.subplots(figsize=(12, 8))
ax.imshow(img)

for x, y, w, h in gt_boxes:
    ax.add_patch(plt.Rectangle((x, y), w, h, fill=False, edgecolor="lime", linewidth=1.5))

for (x, y, w, h), score in pred_boxes:
    ax.add_patch(plt.Rectangle((x, y), w, h, fill=False, edgecolor="red", linewidth=1.5))

ax.set_title(f"Failure Case: {fname} | Ground Truth={len(gt_boxes)} (green), Predicted={len(pred_boxes)} (red)")
ax.axis("off")
plt.tight_layout()
out = Path("/kaggle/working/outputs/stage4_failure_case_01077.png")
plt.savefig(out, dpi=150, bbox_inches="tight")
print("Saved:", out)
